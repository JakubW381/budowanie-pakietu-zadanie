Name:		htopjw
Version:	3.0
Release:	1
Summary:	Process Viewer
License:	GPL

%description
pakiet z htop

%install
mkdir -p %{buildroot}/usr/bin
cp /root/rpmbuild/htop/htop %{buildroot}/usr/bin/htop

%files
/usr/bin/htop
