/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Defined to the return type of the 'backtrace' function. */
#define BACKTRACE_RETURN_TYPE __typeof__(backtrace((void**)1, 0))

/* Define if building static binary. */
/* #undef BUILD_STATIC */

/* Define if CPU temperature option should be enabled. */
/* #undef BUILD_WITH_CPU_TEMP */

/* Configuration path. */
#define CONFIGDIR "/.config"

/* Copyright message. */
#define COPYRIGHT "(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team."

/* Predefine ncurses macro. */
/* #undef ERR */

/* Define if sched_setaffinity and sched_getaffinity are to be used. */
#define HAVE_AFFINITY 1

/* The access attribute is supported. */
#define HAVE_ATTR_ACCESS 1

/* The alloc_size attribute is supported. */
#define HAVE_ATTR_ALLOC_SIZE 1

/* The nonnull attribute is supported. */
#define HAVE_ATTR_NONNULL 1

/* The returns_nonnull attribute is supported. */
#define HAVE_ATTR_RETNONNULL 1

/* Define if the backtrace feature is enabled */
/* #undef HAVE_BACKTRACE_SCREEN */

/* Define to 1 if the compiler supports '__builtin_ctz' function. */
#define HAVE_BUILTIN_CTZ 1

/* Define to 1 if you have the <curses.h> header file. */
/* #undef HAVE_CURSES_H */

/* Define to 1 if you have the declaration of 'kIOMainPortDefault', and to 0
   if you don't. */
/* #undef HAVE_DECL_KIOMAINPORTDEFAULT */

/* Define if delay accounting support should be enabled. */
/* #undef HAVE_DELAYACCT */

/* Define to 1 if you have the <demangle.h> header file. */
/* #undef HAVE_DEMANGLE_H */

/* Define to 1 if the demangling is supported. */
/* #undef HAVE_DEMANGLING */

/* Define to 1 if you have the <dirent.h> header file, and it defines 'DIR'.
   */
#define HAVE_DIRENT_H 1

/* Define to 1 if you have the 'dladdr' function. */
#define HAVE_DLADDR 1

/* Define to 1 if you have the <execinfo.h> header file. */
#define HAVE_EXECINFO_H 1

/* Define to 1 if you have the 'faccessat' function. */
#define HAVE_FACCESSAT 1

/* Define to 1 if you have the 'fstatat' function. */
#define HAVE_FSTATAT 1

/* Define to 1 if you have the 'getmouse' function. */
#define HAVE_GETMOUSE 1

/* Define to 1 if you have the 'host_get_clock_service' function. */
/* #undef HAVE_HOST_GET_CLOCK_SERVICE */

/* Define to 1 if you have the 'host_statistics64' function. */
/* #undef HAVE_HOST_STATISTICS64 */

/* Define to 1 if you have the <hwloc.h> header file. */
/* #undef HAVE_HWLOC_H */

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the 'cap' library (-lcap). */
/* #undef HAVE_LIBCAP */

/* Define to 1 if libdemangle supports cplus_demangle function. */
/* #undef HAVE_LIBDEMANGLE_CPLUS_DEMANGLE */

/* Define to 1 if you have the 'hwloc' library (-lhwloc). */
/* #undef HAVE_LIBHWLOC */

/* Define to 1 if libiberty supports cplus_demangle function. */
/* #undef HAVE_LIBIBERTY_CPLUS_DEMANGLE */

/* Define to 1 if you have the <libiberty/demangle.h> header file. */
/* #undef HAVE_LIBIBERTY_DEMANGLE_H */

/* libcurses is present */
/* #undef HAVE_LIBNCURSES */

/* libncursesw is present */
#define HAVE_LIBNCURSESW 1

/* Define to 1 if you have the 'sensors' library (-lsensors). */
/* #undef HAVE_LIBSENSORS */

/* Define to 1 if you have the 'systemd' library (-lsystemd). */
/* #undef HAVE_LIBSYSTEMD */

/* Define if libunwind has unw_get_elf_filename */
/* #undef HAVE_LIBUNWIND_ELF_FILENAME */

/* Define to 1 if you have the <libunwind.h> header file. */
/* #undef HAVE_LIBUNWIND_H */

/* Define to 1 if libunwind-ptrace is present */
/* #undef HAVE_LIBUNWIND_PTRACE */

/* Define to 1 if local unwinding is enabled. */
/* #undef HAVE_LOCAL_UNWIND */

/* Define to 1 if you have the <mach/mach_time.h> header file. */
/* #undef HAVE_MACH_MACH_TIME_H */

/* Define to 1 if you have the 'mach_timebase_info' function. */
/* #undef HAVE_MACH_TIMEBASE_INFO */

/* Define to 1 if <wchar.h> declares mbstate_t. */
#define HAVE_MBSTATE_T 1

/* Define to 1 if you have the 'memfd_create' function. */
#define HAVE_MEMFD_CREATE 1

/* Define to 1 if you have the <minix/config.h> header file. */
/* #undef HAVE_MINIX_CONFIG_H */

/* Define to 1 if you have the <ncursesw/curses.h> header file. */
#define HAVE_NCURSESW_CURSES_H 1

/* Define to 1 if you have the <ncursesw/term.h> header file. */
#define HAVE_NCURSESW_TERM_H 1

/* Define to 1 if you have the <ncurses/curses.h> header file. */
/* #undef HAVE_NCURSES_CURSES_H */

/* Define to 1 if you have the <ncurses.h> header file. */
/* #undef HAVE_NCURSES_H */

/* Define to 1 if you have the <ncurses/ncurses.h> header file. */
/* #undef HAVE_NCURSES_NCURSES_H */

/* Define to 1 if you have the <ncurses/term.h> header file. */
/* #undef HAVE_NCURSES_TERM_H */

/* Define to 1 if you have the <ndir.h> header file, and it defines 'DIR'. */
/* #undef HAVE_NDIR_H */

/* Define to 1 if you have the <netlink/attr.h> header file. */
/* #undef HAVE_NETLINK_ATTR_H */

/* Define to 1 if you have the <netlink/handlers.h> header file. */
/* #undef HAVE_NETLINK_HANDLERS_H */

/* Define to 1 if you have the <netlink/msg.h> header file. */
/* #undef HAVE_NETLINK_MSG_H */

/* Define to 1 if you have the 'openat' function. */
#define HAVE_OPENAT 1

/* Define to 1 if you have the <pcp/pmapi.h> header file. */
/* #undef HAVE_PCP_PMAPI_H */

/* Define to 1 if you have the 'pmLookupDescs' function. */
/* #undef HAVE_PMLOOKUPDESCS */

/* Define to 1 if you have the 'pmtimespecToReal' function. */
/* #undef HAVE_PMTIMESPECTOREAL */

/* Define to 1 if you have the 'pmtimevalTotimespec' function. */
/* #undef HAVE_PMTIMEVALTOTIMESPEC */

/* Define to 1 if you have the 'readlinkat' function. */
#define HAVE_READLINKAT 1

/* Define to 1 if you have the 'sched_getscheduler' function. */
#define HAVE_SCHED_GETSCHEDULER 1

/* Define to 1 if you have the 'sched_setscheduler' function. */
#define HAVE_SCHED_SETSCHEDULER 1

/* Define to 1 if you have the <sensors/sensors.h> header file. */
/* #undef HAVE_SENSORS_SENSORS_H */

/* Define to 1 if you have the 'set_escdelay' function. */
#define HAVE_SET_ESCDELAY 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the 'strchrnul' function. */
#define HAVE_STRCHRNUL 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the 'strnlen' function. */
#define HAVE_STRNLEN 1

/* Define to 1 if the system has the type 'struct vm_statistics64'. */
/* #undef HAVE_STRUCT_VM_STATISTICS64 */

/* Define to 1 if 'compressor_page_count' is a member of 'struct
   vm_statistics64'. */
/* #undef HAVE_STRUCT_VM_STATISTICS64_COMPRESSOR_PAGE_COUNT */

/* Define to 1 if 'internal_page_count' is a member of 'struct
   vm_statistics64'. */
/* #undef HAVE_STRUCT_VM_STATISTICS64_INTERNAL_PAGE_COUNT */

/* Define to 1 if you have the <sys/capability.h> header file. */
/* #undef HAVE_SYS_CAPABILITY_H */

/* Define to 1 if you have the <sys/dir.h> header file, and it defines 'DIR'.
   */
/* #undef HAVE_SYS_DIR_H */

/* Define to 1 if you have the <sys/ndir.h> header file, and it defines 'DIR'.
   */
/* #undef HAVE_SYS_NDIR_H */

/* Define to 1 if you have the <sys/param.h> header file. */
#define HAVE_SYS_PARAM_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/utsname.h> header file. */
#define HAVE_SYS_UTSNAME_H 1

/* Define to 1 if you have the <term.h> header file. */
/* #undef HAVE_TERM_H */

/* Define to 1 if the system has the type 'thread_extended_info_data_t'. */
/* #undef HAVE_THREAD_EXTENDED_INFO_DATA_T */

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the <wchar.h> header file. */
#define HAVE_WCHAR_H 1

/* Building for Darwin. */
/* #undef HTOP_DARWIN */

/* Building for DragonFlyBSD. */
/* #undef HTOP_DRAGONFLYBSD */

/* Building for FreeBSD. */
/* #undef HTOP_FREEBSD */

/* Building for Linux. */
#define HTOP_LINUX /**/

/* Building for NetBSD. */
/* #undef HTOP_NETBSD */

/* Building for OpenBSD. */
/* #undef HTOP_OPENBSD */

/* Define if building pcp-htop binary. */
/* #undef HTOP_PCP */

/* Building for Solaris. */
/* #undef HTOP_SOLARIS */

/* Building for an unsupported platform. */
/* #undef HTOP_UNSUPPORTED */

/* libnl-3 search path; use the default search paths if empty */
/* #undef LIBNL3_LIBDIR */

/* Define to 1 if 'major', 'minor', and 'makedev' are declared in <mkdev.h>.
   */
/* #undef MAJOR_IN_MKDEV */

/* Define to 1 if 'major', 'minor', and 'makedev' are declared in
   <sysmacros.h>. */
#define MAJOR_IN_SYSMACROS 1

/* Define to enable stdbool.h in ncurses */
#define NCURSES_ENABLE_STDBOOL_H 1

/* Name of package */
#define PACKAGE "htop"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "htop@groups.io"

/* Define to the full name of this package. */
#define PACKAGE_NAME "htop"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "htop 3.6.0-dev-3.5.1-79-g81ed8c1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "htop"

/* Define to the home page for this package. */
#define PACKAGE_URL "https://htop.dev/"

/* Define to the version of this package. */
#define PACKAGE_VERSION "3.6.0-dev-3.5.1-79-g81ed8c1"

/* Path of proc filesystem. */
#define PROCDIR "/proc"

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Enable extensions on AIX, Interix, z/OS.  */
#ifndef _ALL_SOURCE
# define _ALL_SOURCE 1
#endif
/* Enable general extensions on macOS.  */
#ifndef _DARWIN_C_SOURCE
# define _DARWIN_C_SOURCE 1
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# define __EXTENSIONS__ 1
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif
/* Enable X/Open compliant socket functions that do not require linking
   with -lxnet on HP-UX 11.11.  */
#ifndef _HPUX_ALT_XOPEN_SOCKET_API
# define _HPUX_ALT_XOPEN_SOCKET_API 1
#endif
/* Identify the host operating system as Minix.
   This macro does not affect the system headers' behavior.
   A future release of Autoconf may stop defining this macro.  */
#ifndef _MINIX
/* # undef _MINIX */
#endif
/* Enable general extensions on NetBSD.
   Enable NetBSD compatibility extensions on Minix.  */
#ifndef _NETBSD_SOURCE
# define _NETBSD_SOURCE 1
#endif
/* Enable OpenBSD compatibility extensions on NetBSD.
   Oddly enough, this does nothing on OpenBSD.  */
#ifndef _OPENBSD_SOURCE
# define _OPENBSD_SOURCE 1
#endif
/* Define to 1 if needed for POSIX-compatible behavior.  */
#ifndef _POSIX_SOURCE
/* # undef _POSIX_SOURCE */
#endif
/* Define to 2 if needed for POSIX-compatible behavior.  */
#ifndef _POSIX_1_SOURCE
/* # undef _POSIX_1_SOURCE */
#endif
/* Enable POSIX-compatible threading on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# define _POSIX_PTHREAD_SEMANTICS 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-5:2014.  */
#ifndef __STDC_WANT_IEC_60559_ATTRIBS_EXT__
# define __STDC_WANT_IEC_60559_ATTRIBS_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-1:2014.  */
#ifndef __STDC_WANT_IEC_60559_BFP_EXT__
# define __STDC_WANT_IEC_60559_BFP_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-2:2015.  */
#ifndef __STDC_WANT_IEC_60559_DFP_EXT__
# define __STDC_WANT_IEC_60559_DFP_EXT__ 1
#endif
/* Enable extensions specified by C23 Annex F.  */
#ifndef __STDC_WANT_IEC_60559_EXT__
# define __STDC_WANT_IEC_60559_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-4:2015.  */
#ifndef __STDC_WANT_IEC_60559_FUNCS_EXT__
# define __STDC_WANT_IEC_60559_FUNCS_EXT__ 1
#endif
/* Enable extensions specified by C23 Annex H and ISO/IEC TS 18661-3:2015.  */
#ifndef __STDC_WANT_IEC_60559_TYPES_EXT__
# define __STDC_WANT_IEC_60559_TYPES_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TR 24731-2:2010.  */
#ifndef __STDC_WANT_LIB_EXT2__
# define __STDC_WANT_LIB_EXT2__ 1
#endif
/* Enable extensions specified by ISO/IEC 24747:2009.  */
#ifndef __STDC_WANT_MATH_SPEC_FUNCS__
# define __STDC_WANT_MATH_SPEC_FUNCS__ 1
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# define _TANDEM_SOURCE 1
#endif
/* Enable X/Open extensions.  Define to 500 only if necessary
   to make mbstate_t available.  */
#ifndef _XOPEN_SOURCE
/* # undef _XOPEN_SOURCE */
#endif


/* Version number of package */
#define VERSION "3.6.0-dev-3.5.1-79-g81ed8c1"

/* Number of bits in a file offset, on hosts where this is settable. */
/* #undef _FILE_OFFSET_BITS */

/* Define to 1 on platforms where this makes off_t a 64-bit type. */
/* #undef _LARGE_FILES */

/* Number of bits in time_t, on hosts where this is settable. */
/* #undef _TIME_BITS */

/* Define for Solaris 2.5.1 so the uint32_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT32_T */

/* Define for Solaris 2.5.1 so the uint64_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT64_T */

/* Define for Solaris 2.5.1 so the uint8_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT8_T */


/* Enables XPG4v2 (SUSv1) interfaces if they are not enabled already with _XOPEN_SOURCE */
#ifndef _XOPEN_SOURCE_EXTENDED
#define _XOPEN_SOURCE_EXTENDED 1
#endif


/* Define to 1 on platforms where this makes time_t a 64-bit type. */
/* #undef __MINGW_USE_VC2005_COMPAT */

/* Define as 'int' if <sys/types.h> doesn't define. */
/* #undef gid_t */

/* Define to a type if <wchar.h> does not define. */
/* #undef mbstate_t */

/* Define to 'int' if <sys/types.h> does not define. */
/* #undef mode_t */

/* Define to 'long int' if <sys/types.h> does not define. */
/* #undef off_t */

/* Define as a signed integer type capable of holding a process identifier. */
/* #undef pid_t */

/* Define as 'unsigned int' if <stddef.h> doesn't define. */
/* #undef size_t */

/* Define as 'int' if <sys/types.h> doesn't define. */
/* #undef ssize_t */

/* Define as 'int' if <sys/types.h> doesn't define. */
/* #undef uid_t */

/* Define to the type of an unsigned integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint16_t */

/* Define to the type of an unsigned integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint32_t */

/* Define to the type of an unsigned integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint64_t */

/* Define to the type of an unsigned integer type of width exactly 8 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint8_t */
